<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css">
	<!-- <link href="css/bootstrap.min.css" rel="stylesheet"> -->
	<script src="js/bootstrap.mid.js"></script>
</head>
<body>
 
	<h1>Halaman Login</h1>

	
 
	<div class="kotak_login">
		<p class="tulisan_login">Silahkan login</p>
 
		<form action="cek_login.php" method="post">
			<label>Username</label>
			<input type="text" name="username" class="form_login" placeholder="Username .." required="required">
 
			<label>Password</label>
			<input type="password" name="password" class="form_login" placeholder="Password .." required="required">
 
			<input type="submit" class="tombol_login" value="LOGIN">
 
			<br/>
			<br/>
			<center>
				<a class="link" href="halaman_user.php">Belum Punya Akun?</a>
			</center>
		</form>
		
	</div>
 
 
</body>
</html><?php /**PATH E:\xampp\htdocs\web-crud\resources\views/login.blade.php ENDPATH**/ ?>