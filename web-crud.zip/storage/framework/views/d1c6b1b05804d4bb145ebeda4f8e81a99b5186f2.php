<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>No</th>
					<th>Nomor Plat</th>
					<th>Merk Kendaraan</th>
					<th>Tipe Kendaraan</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->id); ?></td>
            <td><?php echo e($item->noplat); ?></td>
            <td><?php echo e($item->merk); ?></td>
            <td><?php echo e($item->tipe); ?></td>
            <td>
                <button class="btn btn-warning" onClick="show(<?php echo e($item->id); ?>)">Edit</button>
                <button class="btn btn-danger" onClick="destroy(<?php echo e($item->id); ?>)">Delete</button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
<?php /**PATH E:\xampp\htdocs\web-crud\resources\views/read.blade.php ENDPATH**/ ?>