<div class="p2">
    <div class="form-group">
        <label for="plat">NO PLAT</label>
        <input type="text" name="plat" id="plat" class="form-control">

        <label for="merk">MERK MOTOR</label>
        <input type="text" name="merk" id="merk" class="form-control">

        <label for="tipe">TIPE MOTOR</label>
        <input type="text" name="tipe" id="tipe" class="form-control">
    </div>
    <div class="form-group mt-2">
        <button class="btn btn-success" onClick="">Tambah</button>
    </div>
</div>